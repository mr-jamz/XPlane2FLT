import JSZip, { type JSZipObject } from "jszip";
import { parseAcf } from "../core/acf";
import { parseOptionDefaults } from "../core/options";
import { buildOpenFlight, countOpenFlightGeometryObjects, validateOpenFlight } from "./openflight";
import { parseObj8 } from "./obj8";
import { optimizeModels } from "./optimizer";
import { resizeTexture } from "./texture";
import {
  basename,
  dirname,
  extension,
  normalizeArchivePath,
  removeExtension,
  resolveRelativePath,
  safeFileStem,
} from "./path";
import type {
  ArchiveEntrySummary,
  ArchiveInspection,
  ConversionOptions,
  ConversionResult,
  Diagnostic,
  Obj8Model,
} from "./types";
import type { AircraftAttachment } from "../core/types";

type ArchiveSource = Blob | ArrayBuffer | Uint8Array;

const TEXTURE_EXTENSIONS = new Set(["png", "dds", "bmp", "jpg", "jpeg", "tga", "tif", "tiff", "rgb", "rgba"]);
const SUPPORT_EXTENSIONS = new Set(["attr", "txt", "ini", "json", "cfg", "lua", "wav"]);

function entrySize(entry: JSZipObject): number {
  const internal = entry as JSZipObject & { _data?: { uncompressedSize?: number } };
  return internal._data?.uncompressedSize ?? 0;
}

function classify(path: string): ArchiveEntrySummary["kind"] {
  const ext = extension(path);
  if (ext === "acf") return "aircraft";
  if (ext === "obj") return "object";
  if (TEXTURE_EXTENSIONS.has(ext)) return "texture";
  if (SUPPORT_EXTENSIONS.has(ext)) return "support";
  return "other";
}

function sourceByteLength(source: ArchiveSource): number {
  if (source instanceof Blob) return source.size;
  if (source instanceof Uint8Array) return source.byteLength;
  return source.byteLength;
}

function findActualPath(pathLookup: Map<string, string>, requested: string, fromFile: string): string | undefined {
  const resolved = resolveRelativePath(fromFile, requested);
  const exact = pathLookup.get(resolved.toLowerCase());
  if (exact) return exact;

  const requestedBase = basename(requested).toLowerCase();
  const objectDirectory = dirname(fromFile).toLowerCase();
  const candidates = [...pathLookup.values()].filter((candidate) => basename(candidate).toLowerCase() === requestedBase);
  const exactName = candidates.find((candidate) => dirname(candidate).toLowerCase() === objectDirectory) ?? candidates[0];
  if (exactName) return exactName;

  // X-Plane commonly accepts a same-stem DDS in place of the PNG named by an
  // OBJ (and vice versa). Mirror that lookup before declaring it missing.
  const requestedStem = removeExtension(requestedBase).toLowerCase();
  const compatibleExtensions = new Set(["png", "dds", "bmp", "jpg", "jpeg", "tga", "tif", "tiff"]);
  const stemCandidates = [...pathLookup.values()].filter((candidate) => (
    removeExtension(basename(candidate)).toLowerCase() === requestedStem
    && compatibleExtensions.has(extension(candidate))
  ));
  const sameStem = stemCandidates.find((candidate) => dirname(candidate).toLowerCase() === objectDirectory)
    ?? stemCandidates[0];
  if (sameStem) return sameStem;

  // A smaller number of aircraft packages also differ only by a plural suffix
  // (for example pilot.png in the OBJ and pilots.dds in the archive).
  const alternateStem = requestedStem.endsWith("s") ? requestedStem.slice(0, -1) : `${requestedStem}s`;
  return [...pathLookup.values()].find((candidate) => (
    dirname(candidate).toLowerCase() === objectDirectory
    && removeExtension(basename(candidate)).toLowerCase() === alternateStem
    && compatibleExtensions.has(extension(candidate))
  ));
}

function modelMatchesAttachment(modelPath: string, attachmentPath: string): boolean {
  const model = normalizeArchivePath(modelPath).toLowerCase();
  const attachment = normalizeArchivePath(attachmentPath).toLowerCase();
  return model === attachment || model.endsWith(`/${attachment}`) || attachment.endsWith(`/${model}`);
}

function resolveModelTextures(model: Obj8Model, lookup: Map<string, string>, diagnostics: Diagnostic[]): Obj8Model {
  const resolve = (requested: string | undefined, kind: string): string | undefined => {
    if (!requested) return undefined;
    const actual = findActualPath(lookup, requested, model.path);
    if (!actual) {
      diagnostics.push({
        severity: "warning",
        code: "MISSING_TEXTURE",
        file: model.path,
        message: `${kind} texture “${requested}” was not found in the aircraft archive.`,
      });
    }
    return actual;
  };

  return {
    ...model,
    texturePath: resolve(model.texturePath, "Diffuse"),
    litTexturePath: resolve(model.litTexturePath, "Lit"),
    normalTexturePath: resolve(model.normalTexturePath, "Normal"),
  };
}

async function loadArchive(source: ArchiveSource): Promise<JSZip> {
  try {
    return await JSZip.loadAsync(source, { checkCRC32: false, createFolders: false });
  } catch (error) {
    throw new Error(`The selected file is not a readable ZIP archive: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function inspectArchive(source: ArchiveSource, archiveName = "aircraft.zip"): Promise<ArchiveInspection> {
  const zip = await loadArchive(source);
  const diagnostics: Diagnostic[] = [];
  const entries: ArchiveEntrySummary[] = [];
  const entryObjects = new Map<string, JSZipObject>();
  const pathLookup = new Map<string, string>();

  for (const [zipPath, entry] of Object.entries(zip.files)) {
    if (entry.dir) continue;
    const normalized = normalizeArchivePath(zipPath);
    if (!normalized) continue;
    if (normalized !== zipPath.replace(/\\/g, "/").replace(/^\/+/, "")) {
      diagnostics.push({
        severity: "warning",
        code: "PATH_NORMALIZED",
        file: zipPath,
        message: "An unsafe or non-canonical archive path was normalized before processing.",
      });
    }
    const key = normalized.toLowerCase();
    if (pathLookup.has(key)) {
      diagnostics.push({
        severity: "warning",
        code: "DUPLICATE_PATH",
        file: normalized,
        message: "A duplicate case-insensitive archive path was ignored.",
      });
      continue;
    }
    pathLookup.set(key, normalized);
    entryObjects.set(normalized, entry);
    entries.push({ path: normalized, size: entrySize(entry), kind: classify(normalized) });
  }

  const aircraftFiles = entries.filter((entry) => entry.kind === "aircraft").map((entry) => entry.path);
  const objectFiles = entries.filter((entry) => entry.kind === "object").map((entry) => entry.path);
  const textureFiles = entries.filter((entry) => entry.kind === "texture").map((entry) => entry.path);
  const parsedModels: Obj8Model[] = [];
  const datarefPrefixes = new Set<string>();
  const aircraftAttachments: AircraftAttachment[] = [];

  for (const path of aircraftFiles) {
    const sourceText = await entryObjects.get(path)!.async("string");
    const manifest = parseAcf(path, sourceText);
    for (const warning of manifest.warnings) {
      diagnostics.push({ severity: "warning", code: "ACF_PARSE_WARNING", file: path, message: warning });
    }
    aircraftAttachments.push(...manifest.attachments);
    for (const attachment of manifest.attachments) {
      const prefix = attachment.hideDataref?.match(/^(.+?)\/kill\//i)?.[1];
      if (prefix) datarefPrefixes.add(prefix);
    }
  }

  const optionPath = entries.find((entry) => /(^|\/)opt_config\.ini$/i.test(entry.path))?.path;
  const configurationDatarefs = optionPath && datarefPrefixes.size > 0
    ? parseOptionDefaults(await entryObjects.get(optionPath)!.async("string"), [...datarefPrefixes])
    : {};

  const objectSources = new Map<string, string>();
  await Promise.all(objectFiles.map(async (path) => {
    objectSources.set(path, await entryObjects.get(path)!.async("string"));
  }));

  // SASL configuration modules often create additional numeric datarefs that
  // are not persisted in opt_config.ini (for example hose, cable, basket, and
  // deployment ratios). X-Plane initializes those numeric datarefs to zero.
  // Discover only the known aircraft's /conf/ namespace and reproduce that
  // deterministic initial value; unrelated live simulator datarefs stay absent.
  const knownPrefixes = new Set([...datarefPrefixes].map((prefix) => prefix.toLowerCase()));
  const configuredKeys = new Set(Object.keys(configurationDatarefs).map((dataref) => dataref.toLowerCase()));
  const inferredConfigurationDatarefs: string[] = [];
  for (const sourceText of objectSources.values()) {
    for (const match of sourceText.matchAll(/\b([a-z0-9_.-]+(?:\/[a-z0-9_.-]+)*\/conf\/[a-z0-9_.\-\[\]]+)/gi)) {
      const dataref = match[1];
      const prefix = dataref.slice(0, dataref.toLowerCase().indexOf("/conf/")).toLowerCase();
      if (!knownPrefixes.has(prefix) || configuredKeys.has(dataref.toLowerCase())) continue;
      configurationDatarefs[dataref] = 0;
      configuredKeys.add(dataref.toLowerCase());
      inferredConfigurationDatarefs.push(dataref);
    }
  }
  inferredConfigurationDatarefs.sort((left, right) => left.localeCompare(right));
  if (inferredConfigurationDatarefs.length > 0) {
    diagnostics.push({
      severity: "info",
      code: "CONFIGURATION_ZERO_DEFAULTS_INFERRED",
      message: `${inferredConfigurationDatarefs.length} aircraft configuration dataref${inferredConfigurationDatarefs.length === 1 ? " was" : "s were"} absent from opt_config.ini and initialized to X-Plane's numeric default of zero.`,
    });
  }

  for (const path of objectFiles) {
    const sourceText = objectSources.get(path)!;
    const matchingAttachments = aircraftAttachments.filter((attachment) => modelMatchesAttachment(path, attachment.path));
    const instances: Array<AircraftAttachment | undefined> = matchingAttachments.length > 0 ? matchingAttachments : [undefined];
    for (const attachment of instances) {
      const model = parseObj8(path, sourceText, {
        datarefs: configurationDatarefs,
        attachment: attachment ? {
          index: attachment.index,
          position: attachment.position,
          rotation: attachment.rotation,
        } : undefined,
      });
      diagnostics.push(...model.diagnostics);
      parsedModels.push(resolveModelTextures(model, pathLookup, diagnostics));
    }
  }

  if (aircraftFiles.length === 0) {
    diagnostics.push({ severity: "warning", code: "NO_ACF", message: "No .acf aircraft definition was found; OBJ8 files can still be converted directly." });
  }
  if (objectFiles.length === 0) {
    diagnostics.push({ severity: "error", code: "NO_OBJ8", message: "No X-Plane .obj geometry files were found in the archive." });
  }
  if (aircraftFiles.length > 0 && objectFiles.length > 0) {
    diagnostics.push({
      severity: "info",
      code: "ACF_CONFIGURATION_POSE_BAKED",
      message: "Saved aircraft configuration, deterministic OBJ8 transforms, and ACF attachment placement are baked into export geometry. Unavailable live simulator animations remain in their authored neutral pose.",
    });
  }

  const commonRoot = entries.length > 0 && entries.every((entry) => entry.path.includes("/"))
    ? entries[0].path.split("/")[0]
    : safeFileStem(archiveName);

  return {
    archiveName,
    rootName: commonRoot,
    entries: entries.sort((a, b) => a.path.localeCompare(b.path)),
    aircraftFiles,
    objectFiles,
    textureFiles,
    models: parsedModels,
    configurationDatarefs,
    inferredConfigurationDatarefs,
    diagnostics,
    totals: {
      files: entries.length,
      vertices: parsedModels.reduce((sum, model) => sum + model.vertices.length, 0),
      triangles: parsedModels.reduce((sum, model) => sum + model.triangles.length, 0),
      sourceBytes: sourceByteLength(source),
    },
  };
}

function makeOutputPath(sourcePath: string, used: Set<string>): string {
  const objectPrefix = safeFileStem(dirname(sourcePath).split("/").pop() || "asset");
  const fileName = basename(sourcePath).replace(/[^a-zA-Z0-9._-]+/g, "-");
  let candidate = `textures/${fileName}`;
  let suffix = 2;
  while (used.has(candidate.toLowerCase())) {
    candidate = `textures/${objectPrefix}-${suffix}-${fileName}`;
    suffix += 1;
  }
  used.add(candidate.toLowerCase());
  return candidate;
}

export async function convertArchive(
  source: ArchiveSource,
  inspection: ArchiveInspection,
  options: ConversionOptions,
): Promise<ConversionResult> {
  let lastProgress = -1;
  const report = (percent: number, stage: string) => {
    const next = Math.max(lastProgress, Math.min(100, Math.round(percent)));
    if (next === lastProgress && next !== 100) return;
    lastProgress = next;
    options.onProgress?.({ percent: next, stage });
  };
  const yieldToBrowser = () => new Promise<void>((resolve) => setTimeout(resolve, 0));
  report(2, "Reading aircraft archive");
  if (inspection.diagnostics.some((diagnostic) => diagnostic.severity === "error")) {
    throw new Error("The archive contains blocking errors. Resolve them before converting.");
  }
  const zip = await loadArchive(source);
  report(10, "Selecting aircraft objects");
  const selectedPathSet = new Set(options.selectedModelPaths.map((path) => path.toLowerCase()));
  const selectedModels = inspection.models.filter((model) => selectedPathSet.has(model.path.toLowerCase()));
  if (selectedModels.length === 0) throw new Error("Select at least one OBJ8 mesh before converting.");
  const untexturedModels = selectedModels.filter((model) => model.triangles.length > 0 && !model.texturePath);
  if (untexturedModels.length > 0 && !options.allowMissingDiffuseTextures) {
    const examples = untexturedModels.slice(0, 4).map((model) => basename(model.path)).join(", ");
    throw new Error(
      `${untexturedModels.length} selected mesh${untexturedModels.length === 1 ? "" : "es"} have no resolvable diffuse texture`
      + ` (${examples}${untexturedModels.length > 4 ? ", …" : ""}). Add the missing PNG/DDS files, deselect those meshes, or confirm that you want to export them without diffuse textures.`,
    );
  }
  report(18, "Optimizing geometry");
  await yieldToBrowser();
  const optimized = optimizeModels(selectedModels, options.optimization);
  if (optimized.diagnostics.some((diagnostic) => diagnostic.severity === "error")) {
    throw new Error(optimized.diagnostics.map((diagnostic) => `${diagnostic.file ?? "Geometry"}: ${diagnostic.message}`).join(" "));
  }
  const exportModels = optimized.models;
  report(48, "Preparing textures");
  await yieldToBrowser();
  const normalizedEntries = new Map<string, JSZipObject>();
  for (const [path, entry] of Object.entries(zip.files)) {
    if (!entry.dir) normalizedEntries.set(normalizeArchivePath(path).toLowerCase(), entry);
  }

  const diffuseSources = [...new Set(selectedModels.map((model) => model.texturePath).filter((value): value is string => Boolean(value)))];
  const auxiliarySources = selectedModels.flatMap((model) => [model.litTexturePath, model.normalTexturePath]).filter((value): value is string => Boolean(value));
  const selectedTextures = options.includeUnreferencedTextures
    ? inspection.textureFiles
    : [...new Set([...diffuseSources, ...auxiliarySources])];

  const usedOutputPaths = new Set<string>();
  const outputPathBySource = new Map<string, string>();
  for (const sourcePath of selectedTextures) {
    outputPathBySource.set(sourcePath.toLowerCase(), makeOutputPath(sourcePath, usedOutputPaths));
  }

  const diffuseBindings = diffuseSources.map((sourcePath, index) => ({
    sourcePath,
    outputPath: outputPathBySource.get(sourcePath.toLowerCase())!,
    index,
  }));

  const outputStem = safeFileStem(options.outputName || inspection.rootName || removeExtension(inspection.archiveName));
  const fltFileName = `${outputStem}.flt`;
  const packageFileName = `${outputStem}-openflight.zip`;
  const flt = buildOpenFlight({
    models: exportModels,
    textures: diffuseBindings,
    coordinateMode: options.coordinateMode,
    databaseId: outputStem,
  });
  report(68, "Validating OpenFlight");
  await yieldToBrowser();
  const validationDiagnostics = validateOpenFlight(flt);
  if (validationDiagnostics.some((diagnostic) => diagnostic.severity === "error")) {
    throw new Error(validationDiagnostics.map((diagnostic) => diagnostic.message).join(" "));
  }

  const outputZip = new JSZip();
  outputZip.file(fltFileName, flt);
  const textureReport: Array<{ source: string; output: string; resized: boolean; width?: number; height?: number }> = [];
  for (let textureIndex = 0; textureIndex < selectedTextures.length; textureIndex += 1) {
    const sourcePath = selectedTextures[textureIndex];
    const entry = normalizedEntries.get(sourcePath.toLowerCase());
    const outputPath = outputPathBySource.get(sourcePath.toLowerCase());
    if (entry && outputPath) {
      const resized = await resizeTexture(await entry.async("uint8array"), outputPath, options.optimization.textureMaxSize);
      outputZip.file(outputPath, resized.bytes);
      textureReport.push({ source: sourcePath, output: outputPath, resized: resized.resized, width: resized.width, height: resized.height });
    }
    report(70 + (selectedTextures.length ? 15 * (textureIndex + 1) / selectedTextures.length : 15), "Packaging textures");
  }

  outputZip.file(
    "conversion-report.json",
    JSON.stringify(
      {
        generator: "XPlane2FLT",
        openFlightVersion: "16.0",
        geometryEncoding: "modelconverterx-compatible-face-5-vertex-palette-67-vertex-list-72",
        sourceArchive: inspection.archiveName,
        coordinateMode: options.coordinateMode,
        configurationDatarefs: inspection.configurationDatarefs,
        inferredConfigurationDatarefs: inspection.inferredConfigurationDatarefs,
        optimization: { settings: options.optimization, ...optimized.stats },
        objects: exportModels.map((model, index) => ({
          source: model.path,
          vertices: model.vertices.length,
          triangles: model.triangles.length,
          originalTriangles: selectedModels[index].triangles.length,
          diffuseTexture: model.texturePath ?? null,
          hierarchyParts: (() => {
            const counts = new Map<string, number>();
            for (const triangle of model.triangles) {
              const id = triangle.hierarchyPartId ?? "static";
              counts.set(id, (counts.get(id) ?? 0) + 1);
            }
            const metadata = new Map((model.hierarchyParts ?? []).map((part) => [part.id, part]));
            return [...counts].map(([id, triangles]) => ({
              id,
              name: metadata.get(id)?.name ?? (id === "static" ? "STATIC" : id),
              triangles,
              datarefs: metadata.get(id)?.datarefs ?? [],
            }));
          })(),
          excludedByVisibility: model.excludedByVisibility ?? 0,
          bakedTransforms: model.bakedTransformCount ?? 0,
          skippedLiveTransforms: model.skippedLiveTransformCount ?? 0,
          acfAttachmentIndex: model.attachmentIndex ?? null,
          acfAttachmentTransformApplied: model.attachmentTransformApplied ?? false,
        })),
        copiedTextures: textureReport,
        diagnostics: [...inspection.diagnostics, ...optimized.diagnostics],
      },
      null,
      2,
    ),
  );

  report(86, "Compressing output package");
  const packageZip = await outputZip.generateAsync({
    type: "uint8array",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
    platform: "UNIX",
  }, (metadata) => report(86 + metadata.percent * 0.13, "Compressing output package"));

  report(100, "Conversion complete");

  return {
    flt,
    packageZip,
    fltFileName,
    packageFileName,
    diagnostics: [...inspection.diagnostics, ...optimized.diagnostics, ...validationDiagnostics],
    textureCount: selectedTextures.length,
    objectCount: countOpenFlightGeometryObjects(exportModels),
    triangleCount: optimized.stats.optimizedTriangles,
    optimization: optimized.stats,
  };
}
